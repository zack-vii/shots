/********************************************************************
 *	Kalendae, a framework agnostic javascript date picker           *
 *	Copyright(c) 2013-2017 Jocelyn Badgley (joc@twipped.com)        *
 *	http://github.com/Twipped/Kalendae                              *
 *	Version 0.7.1                                                   *
 ********************************************************************/
